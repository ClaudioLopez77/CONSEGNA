
-- CREAZIONE TABELLA CONCESSIONARIA

CREATE TABLE Concessionaria (
    Conc_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    Conc_Nome VARCHAR(255),
    Conc_Citta VARCHAR(255),
    Conc_Indirizzo VARCHAR(255),
    Conc_Responsabile VARCHAR(255),
    Conc_Regione VARCHAR(255)
);
	

INSERT INTO Concessionaria (Conc_Nome, Conc_Citta, Conc_Indirizzo, Conc_Responsabile, Conc_Regione)
VALUES 
    ('AUTOMAGENTA', 'Milano','Via Magenta 2', 'Mario Rossi','Lombardia'),  
    ('Auto Roma', 'Roma','Via Tiburtina 1166', 'Giuseppe Verdi','Lazio'),  
    ('Auto Napoli', 'Napoli','Via Nuova Poggioreale 25','Pietro Giallo','Campania'), 
    ('Auto Torino', 'Torino','Corso Giulio Cesare 375','Anna Blu','Piemonte'), 
    ('Auto Bari', 'Bari','Via Amendola 172','Maria Verdi','Puglia');
      
	 -- CREAZIONE TABELLA AUTO 	  
	  
	  create table if not exists Auto (
  auto_Targa varchar(7) not null,
  auto_Marca varchar (255) not null,
  auto_Colore varchar (255) not null,
  auto_Cilindrata int not null,
  auto_Tipo_cambio varchar (255) not null , 
  auto_Prezzo decimal (10,2) not null , 
  auto_Conc_id  int not null ,
  primary key (auto_targa),
  foreign key (auto_Conc_id) references Concessionaria (Conc_id)
  );
  
  -- CREAZIONE TABELLA PROPRIETARI 
  
  create table if not exists Proprietari( 
    cust_id int not null auto_increment, 
    cust_Targa varchar(7) not null,
    cust_Nominativo varchar(255) not null ,
    cust_Citta_residenza varchar (255) not null ,
    cust_Anno_Acquisto datetime ,
    cust_Anno_vendita datetime,
    primary key (cust_id),
    foreign key (cust_Targa) references Auto (auto_Targa)
    );


-- CREAZIONE TABELLA VENDITE 

create table if not exists Vendite (
  Fattura_id int not null auto_increment,
  Conc_id int not null , 
	auto_Targa varchar (255),
	cust_id int not null ,
  primary key (Fattura_id) ,
  foreign key (Conc_id) references Concessionaria (Conc_id),
  foreign key (auto_Targa) references Auto (auto_Targa),
  foreign key (cust_id) references Proprietari (cust_id)
  );
  



INSERT INTO Auto (auto_Targa, auto_Marca, auto_Colore, auto_Cilindrata, auto_Tipo_cambio, auto_Prezzo, auto_Conc_id) VALUES
('ABC123', 'Fiat', 'Red', 1600, 'Manual', 15000, 1),
('DEF456', 'Ford', 'Blue', 1800, 'Automatic', 20000, 1),
('ASC123', 'Dacia', 'Red', 1100, 'Manual', 15000, 1),
('DEF666', 'Renault', 'Orange', 1800, 'Automatic', 20000, 1),
('EEF666', 'Renault', 'Green', 1800, 'Automatic', 13000, 1),
('GHI789', 'Volkswagen', 'Black', 2000, 'Manual', 22000.00, 2),
('JKL012', 'Renault', 'White', 1500, 'Manual', 18000.00, 2),
('GHI799', 'Volkswagen', 'Black', 2000, 'Manual', 22000.00, 2),
('JKK013', 'FIAT', 'White', 1500, 'Manual', 18000.00, 2),
('JKK012', 'FIAT', 'Black', 1500, 'Manual', 18000.00, 2),
('MNO435', 'Toyota', 'Silver', 1800, 'Automatic', 25000.00, 3),
('PQR677', 'BMW', 'Green', 2200, 'Automatic', 30000.00, 3),
('MMN465', 'Toyota', 'Silver', 1800, 'Manual', 25000.00, 3),
('PQR678', 'BMW', 'Green', 2200, 'Automatic', 30000.00, 3),
('STU901', 'Mercedes', 'Grey', 2500, 'Automatic', 35000.00, 4),
('VWX234', 'Audi', 'Yellow', 2000, 'Manual', 28000.00, 4),
('GHH999', 'MERCEDES', 'Green', 1100, 'Manual', 22000.00, 4),
('JKK112', 'FIAT', 'White', 1200, 'Manual', 18000.00, 4),
('KKK012', 'FIAT', 'Black', 1500, 'Manual', 18000.00, 4),
('AAA567', 'Opel', 'Orange', 1900, 'Manual', 23000.00, 5),
('BCD890', 'Peugeot', 'Purple', 2100, 'Manual', 24000.00, 5),
('HYA567', 'Opel', 'Red', 1600, 'Manual', 23000.00, 5),
('BAD890', 'Peugeot', 'Red', 2100, 'Automatic', 24000.00, 5),
('GCD890', 'Peugeot', 'Purple', 1700, 'Manual', 24000.00, 5),
('GGC678', 'Fiat', 'Red', 1600, 'automatico', 15000, 1);

INSERT INTO Proprietari (cust_Targa, cust_Nominativo, cust_Citta_residenza, cust_Anno_Acquisto, cust_Anno_vendita) VALUES
('ABC123', 'Mario Rossi', 'Roma', '2018-05-20', NULL),
('DEF456', 'Luca Bianchi', 'Milano', '2019-02-10', '2023-08-15'),
('DEF456', 'Pietro Rosso', 'Milano', '2023-08-16', NULL),
('ASC123', 'Anna Verdi', 'Napoli', '2020-11-30', NULL),
('DEF666', 'Ada Blu', 'Firenze', '2017-08-25', '2019-08-12'),
('DEF666', 'Giulia Neri', 'Firenze', '2019-08-13', NULL),
('EEF666', 'Roberto Gialli', 'Torino', '2019-06-12', NULL),
('GHI789', 'Laura Blu', 'Bologna', '2016-09-18', NULL),
('JKL012', 'Martina Rosa', 'Palermo', '2021-04-05', NULL),
('GHI799', 'Simone Viola', 'Genova', '2018-07-29', NULL),
('JKK013', 'Francesca Gialli', 'Bari', '2019-10-03', NULL),
('JKK012', 'Marco Bianco', 'Catania', '2017-12-15', '2018-11-11'),
('JKK012', 'Davide Marrone', 'Catania', '2018-11-12', NULL),
('MNO435', 'Paolo Arancio', 'Venezia', '2018-03-28', NULL),
('PQR677', 'Elisa Marrone', 'Trieste', '2019-08-07', NULL),
('MMN465', 'Marco Rosso', 'Brescia', '2020-01-15', NULL),
('PQR678', 'Valentina Viola', 'Perugia', '2017-05-10', NULL),
('STU901', 'Alessia Neri', 'Verona', '2018-11-22', NULL),
('VWX234', 'Giovanni Bianchi', 'Messina', '2019-04-30', NULL),
('GHH999', 'Cristina Rossi', 'Reggio Calabria', '2020-07-17', NULL),
('JKK112', 'Giorgio Gialli', 'Foggia', '2017-09-08', NULL),
('KKK012', 'Sara Neri', 'Taranto', '2018-12-03', NULL),
('AAA567', 'Fabio Arancio', 'Modena', '2019-10-25', NULL),
('BCD890', 'Elena Bianchi', 'Parma', '2017-06-14', NULL),
('HYA567', 'Federico Rosso', 'Rimini', '2018-04-19', NULL),
('BAD890', 'Chiara Marrone', 'Livorno', '2020-02-09', NULL),
('GCD890', 'Matteo Arancio', 'Cagliari', '2017-08-30', NULL),
('JKK012', 'Rosa Rosso', 'Catania', '2016-05-14', '2017-12-15'),
('GGC678', 'Paolo Viola', 'MILANO', '2015-05-20', NULL);

INSERT INTO Vendite (Conc_id, auto_Targa, cust_id) values
(1, 'ABC123', 1), 
(1, 'DEF456', 2), 
(1, 'ASC123', 3), 
(1, 'DEF666', 4), 
(1, 'EEF666', 5), 
(2, 'GHI789', 6), 
(2, 'JKL012', 7), 
(2, 'GHI799', 8), 
(2, 'JKK013', 9), 
(2, 'JKK012', 10), 
(3, 'MNO435', 11), 
(3, 'PQR677', 12), 
(3, 'MMN465', 13), 
(3, 'PQR678', 14), 
(4, 'STU901', 15), 
(4, 'VWX234', 16), 
(4, 'GHH999', 17), 
(4, 'JKK112', 18), 
(4, 'KKK012', 19), 
(5, 'AAA567', 20),
(5, 'BCD890', 21), 
(5, 'HYA567', 22), 
(5, 'BAD890', 23), 
(5, 'GCD890', 24),
(1, 'GGC678', 25); 
 /*
1- Marca e Colore delle Auto che costano più di 10.000 €:
*/
SELECT /*distinct*/ auto_Marca, auto_Colore 
FROM Auto 
WHERE auto_Prezzo > 10000;
/*
2- Tutti i proprietari di un’auto di colore ROSSO:
*/
SELECT distinct cust_Nominativo 
FROM Proprietari 
WHERE cust_Targa IN (SELECT auto_Targa FROM Auto WHERE auto_Colore = 'Red');

/*
3- Costo totale di tutte le auto con Cilindrata superiore a 1600:
*/
SELECT distinct SUM(auto_Prezzo) AS "Costo Totale"
FROM Auto 
WHERE auto_Cilindrata > 1600;


/*
4- Targa e Nome del proprietario delle Auto in una concessionaria della Città di Roma:
*/
SELECT distinct
    proprietari.cust_Targa, proprietari.cust_Nominativo,concessionaria.Conc_Citta
FROM
    Proprietari 
        JOIN
    Auto  ON proprietari.cust_Targa = auto.auto_Targa
        JOIN
    Concessionaria  ON auto.auto_Conc_id = concessionaria.Conc_id
WHERE
    concessionaria.Conc_Citta = 'Roma';


/*
5- Per ogni Concessionaria, il numero di Auto:
*/

SELECT c.Conc_Nome, COUNT(*) AS "Numero Auto"
FROM Concessionaria c
JOIN Auto a ON c.Conc_id = a.auto_Conc_id
GROUP BY c.Conc_Nome;

/*
6- Per ogni Concessionaria, il numero di Auto:
*/

SELECT DISTINCT
    co.Conc_Responsabile,
    au.auto_Marca,
    au.auto_Tipo_cambio,
    cu.cust_Anno_Acquisto
FROM
    concessionaria AS co
        INNER JOIN
    auto AS au ON au.auto_Conc_id = co.Conc_id
        INNER JOIN
    proprietari AS cu ON cu.cust_Targa = au.auto_Targa
WHERE
    au.auto_Tipo_cambio = 'Automatic'
        AND YEAR(cu.cust_Anno_Acquisto) = '2018';

 
/*
1- Per ciascuna TARGA il colore, il prezzo e la città in cui si trova il veicolo:
*/
SELECT distinct
    auto_Targa, auto_Colore, auto_Prezzo, Conc_Citta, proprietari.cust_Anno_vendita
FROM
    Auto
        JOIN
    Concessionaria ON Auto.auto_Conc_id = Concessionaria.Conc_id 
    join
    proprietari on proprietari.cust_Targa = auto.auto_Targa
    order by proprietari.cust_Anno_vendita = null ;

/*
2- Le auto con almeno tre Proprietari:
*/

SELECT distinct
    cust_Targa
FROM
    Proprietari
GROUP BY cust_Targa
HAVING COUNT(*) >= 3;

 /*
3- La targa delle auto vendute nel 2015:
*/
SELECT DISTINCT
    cust_Targa
FROM
    Proprietari
WHERE
    YEAR(cust_Anno_vendita) = 2019;


/*
4- La regione con più auto (associata alla città della Concessionaria):
*/
SELECT concessionaria.Conc_Regione, COUNT(*) AS "Numero Auto"
FROM Concessionaria 
JOIN Auto  ON concessionaria.Conc_id = auto.auto_Conc_id
GROUP BY concessionaria.Conc_Regione
ORDER BY COUNT(*) DESC
LIMIT 1;

/*
5- La Targa delle auto che si trovano a Milano, con cambio automatico, colore rosso, di proprietari residenti a Milano:
*/
SELECT 
    distinct cust_Targa, auto.auto_Colore
FROM
    Proprietari
        JOIN
    Auto ON Proprietari.cust_Targa = Auto.auto_Targa
        JOIN
    Concessionaria ON Auto.auto_Conc_id = Concessionaria.Conc_id
WHERE
    Concessionaria.Conc_Citta = 'Milano'
        AND Auto.auto_Tipo_cambio = 'Automatic'
        AND Auto.auto_Colore = 'red';
	
    
    /*---------------------------------------------------------------------------------------------------------------*/
    
   /* 
   6- Il Responsabile di Concessionaria di tutte le auto con Cambio Automatico e Anno Acquisto 2010
   */ 

SELECT distinct
    auto.*, 
    proprietari.*, 
    concessionaria.Conc_Responsabile
FROM 
    auto
JOIN 
    concessionaria ON auto.auto_Conc_id = concessionaria.Conc_id
JOIN 
    proprietari ON auto.auto_Targa = proprietari.cust_Targa
WHERE 
    YEAR(proprietari.cust_Anno_Acquisto) = 2018
    AND auto.auto_Tipo_cambio = 'Automatic';
    
-----------------------------------------------------------------
/*
Gestione fatturato per Concessionaria
*/

SELECT SUM(auto.auto_Prezzo) AS FatturatoTotale
FROM Vendite
join auto on vendite.auto_Targa = auto.auto_Targa;

SELECT SUM(auto.auto_Prezzo) AS FatturatoTotale
FROM Vendite
join proprietari on vendite.cust_id = proprietari.cust_id
join auto on vendite.auto_Targa = auto.auto_Targa
WHERE cust_Anno_Acquisto BETWEEN '2018-01-01' AND '2020-01-01'and conc_id = 2;


SELECT DISTINCT
    auto.auto_Marca, SUM(auto.auto_Prezzo) AS FatturatoPerMarca
FROM
    proprietari
        JOIN
    auto ON proprietari.cust_Targa = auto.auto_Targa
GROUP BY auto.auto_Marca;

-----------------------------------------------------------------------------------------
/*
Gestione Clienti per Concessionaria
*/

SELECT distinct
    *
FROM
    proprietari
WHERE
    cust_id = 13;
    
    
    
UPDATE proprietari 
SET 
    cust_Anno_vendita = '2024-02-28'
WHERE
   cust_id = 1;
 
 
      
  SELECT distinct
    proprietari.*,
    auto.*
FROM
    proprietari
    JOIN auto ON proprietari.cust_Targa = auto.auto_Targa
    JOIN concessionaria ON auto.auto_Conc_id = concessionaria.Conc_id
WHERE
    concessionaria.Conc_id = 2
    order by proprietari.cust_Anno_vendita = null;

    
    SELECT 
    proprietari.*,
    auto.*
FROM
    proprietari
    JOIN auto ON proprietari.cust_Targa = auto.auto_Targa
    JOIN concessionaria ON auto.auto_Conc_id = concessionaria.Conc_id
WHERE
    concessionaria.Conc_id IN (2, 3);
--------------------------------------------------------------------------
select distinct * -- co.Conc_id  , au.auto_Targa , count(*) as ripetizioni
/*sum(case when year (cu.cust_Anno_Acquisto) = 2015 then au.auto_Prezzo else 0 end) as totale_2015,
sum(case when year (cu.cust_Anno_Acquisto) = 2016 then au.auto_Prezzo else 0 end) as totale_2016,
sum(case when year (cu.cust_Anno_Acquisto) = 2017 then au.auto_Prezzo else 0 end) as totale_2017,
sum(case when year (cu.cust_Anno_Acquisto) = 2018 then au.auto_Prezzo else 0 end) as totale_2018,
sum(case when year (cu.cust_Anno_Acquisto) = 2019 then au.auto_Prezzo else 0 end) as totale_2019,
sum(case when year (cu.cust_Anno_Acquisto) = 2020 then au.auto_Prezzo else 0 end) as totale_2020,
sum(case when year (cu.cust_Anno_Acquisto) = 2021 then au.auto_Prezzo else 0 end) as totale_2021,
sum(case when year (cu.cust_Anno_Acquisto) = 2023 then au.auto_Prezzo else 0 end) as totale_2023*/
from vendite as ve
  -- inner join concessionaria as co on co.Conc_id = ve.Conc_id
		 inner join proprietari as cu on cu.cust_Targa = ve.auto_Targa and cu.cust_id = ve.cust_id 
   -- inner join auto as au on au.auto_Conc_id = co.Conc_id
    -- where year (cu.cust_Anno_Acquisto) in (2015,2016,2017,2018,2019,2020,2021,2023)
    -- group by co.Conc_Responsabile , co.Conc_Nome;
-- group by co.Conc_id  , au.auto_Targa 
-- having ripetizioni > 1 ;
order by ve.Fattura_id desc;
