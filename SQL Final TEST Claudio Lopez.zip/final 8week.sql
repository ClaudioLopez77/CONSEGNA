/*
CREO SCHEMA
*/

CREATE SCHEMA ToysGroup_Claudio_LOPEZ;

/*
 Inserisco Tabelle-
 
Creazione della tabella product
*/

CREATE TABLE Product (
    Product_ID INT PRIMARY KEY,
    Product_Name VARCHAR(50),
    Category_ID INT
);

/*
Creazione della tabella Region
*/

CREATE TABLE Region (
    Region_ID INT PRIMARY KEY,
    Region_Name VARCHAR(50)
);

/*
Creazione della tabella Sales
*/
CREATE TABLE Sales (
    Sales_ID INT PRIMARY KEY,
    Product_ID INT,
    Region_ID INT,
    Sale_Date DATE,
    Sale_Amount DECIMAL(10, 2),
    FOREIGN KEY (Product_ID) REFERENCES Product(Product_ID),
    FOREIGN KEY (Region_ID) REFERENCES Region(Region_ID)
);

/*
 Popolamento della tabella Product
 */
 
INSERT INTO Product (Product_ID, Product_Name, Category_ID)
VALUES 
    (1, 'Action Figure', 1),
    (2, 'Doll', 1),
    (3, 'baby Game', 2),
    (4, 'LEGO Set', 3),
    (5, 'Puzzle', 2),
    (6, 'Toys Animal', 1),
    (7, 'Remote Control Car', 1),
    (8, 'Building Blocks', 3),
    (9, 'barby world', 3),
    (10, 'Train', 1),
    (11, 'Educational Toy', 2),
    (12, 'Art Toys', 4),
    (13, 'Musical Instrument', 4),
    (14, 'Outdoor Toy', 5),
    (15, 'Video Game', 6);

/*
Popolamento della tabella Region
*/

INSERT INTO Region (Region_ID, Region_Name)
VALUES 
    (1, 'North America'),
    (2, 'Europe'),
    (3, 'Asia'),
    (4, 'South America'),
    (5, 'Africa'),
    (6, 'Oceania'),
    (7,'Central America'),
    (8,'Canada'),
    (9,'Eastern Europe');

/*
 Popolamento della tabella Sales
 */
 
INSERT INTO Sales (Sales_ID, Product_ID, Region_ID, Sale_Date, Sale_Amount)
VALUES
    (1, 1, 1, '2023-01-05', 50.00),
    (2, 2, 2, '2023-02-10', 40.00),
    (3, 3, 3, '2023-03-15', 30.00),
    (4, 4, 4, '2023-04-20', 60.00),
    (5, 5, 5, '2023-05-25', 25.00),
    (6, 6, 6, '2023-06-30', 35.00),
    (7, 7, 1, '2023-07-05', 45.00),
    (8, 8, 2, '2023-08-10', 55.00),
    (9, 9, 3, '2023-09-15', 65.00),
    (10, 10, 4, '2023-10-20', 70.00),
    (11, 11, 5, '2023-11-25', 20.00),
    (12, 12, 6, '2023-12-30', 75.00),
    (13, 13, 1, '2024-01-05', 80.00),
    (14, 14, 2, '2024-02-10', 85.00),
    (15, 15, 3, '2024-03-15', 90.00);
    
    /*
    1. Verificare che i campi definiti come PK siano univoci.
    */
    

SELECT 
    COUNT(Product_ID) AS Count_ID
FROM
    Product
GROUP BY Product_ID
HAVING COUNT(Product_ID) > 1;

SELECT 
    COUNT(Region_ID) AS Count_ID
FROM
    Region
GROUP BY Region_ID
HAVING COUNT(Region_ID) > 1;

SELECT 
    COUNT(Sales_ID) AS Count_ID
FROM
    Sales
GROUP BY Sales_ID
HAVING COUNT(Sales_ID) > 1;

/*
2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.alter
*/

SELECT 
    product.Product_ID,
    product.Product_Name,
    YEAR(sales.Sale_Date) AS venduti,
    SUM(sales.Sale_Amount) AS anno
FROM
     Product 
        JOIN
    Sales ON product.Product_ID = sales.Product_ID
GROUP BY product.Product_ID , product.Product_Name , YEAR(sales.Sale_Date);

/*
3.Esporre il fatturato totale per regione per anno. Ordina il risultato per data e per fatturato decrescente
*/

SELECT 
    Region.Region_Name,
    YEAR(Sales.Sale_Date) AS fatturato_Anno,
    SUM(Sales.Sale_Amount) AS fatturato_regione
FROM
    Region 
        JOIN
    ToysGroup.Sales ON Region.Region_ID = Sales.Region_ID
GROUP BY Region.Region_Name, YEAR(Sales.Sale_Date)
ORDER BY YEAR(Sales.Sale_Date), SUM(Sales.Sale_Amount) DESC;

/*
4.Qual è la categoria di articoli maggiormente richiesta dal mercato
*/

SELECT product.Product_Name, product.Category_ID, COUNT(*) AS Articoli_piu_venduti
FROM Sales 
JOIN Product  ON sales.Product_ID = product.Product_ID
GROUP BY product.Product_ID, product.Product_Name
ORDER BY Articoli_piu_venduti DESC;
/*
aggiungo campo per resultante null
*/
INSERT INTO Product (Product_ID, Product_Name, Category_ID)
VALUES (16, 'Magic Toys', 7);

/*
Quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti:
Approccio 1: Utilizzo di LEFT JOIN per trovare i prodotti non venduti.
*/
SELECT 
    product.Product_ID, product.Product_Name
FROM
    Product
        LEFT JOIN
    Sales ON product.Product_ID = sales.Product_ID
WHERE
    sales.Sales_ID IS NULL;

/*
Utilizzo di NOT EXISTS per trovare i prodotti non venduti.
*/
SELECT 
    Product_ID, Product_Name
FROM
    Product
WHERE
    NOT EXISTS( SELECT 
            1
        FROM
            Sales
        WHERE
            Product_ID = Product.Product_ID);
            
            
/*Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente)
*/
 SELECT 
    product.Product_ID,
    product.Product_Name,
    MAX(sales.Sale_Date) AS ultima_vendita
FROM
    Product 
        LEFT JOIN
    Sales ON product.Product_ID = sales.Product_ID
GROUP BY product.Product_ID , product.Product_Name;
